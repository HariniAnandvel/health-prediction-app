"""Application settings. Secrets are read from the .env file, never hardcoded."""
import os
import secrets
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


class Config:
    # Used by Flask to protect flash messages. A random one is made if .env has none.
    SECRET_KEY = os.getenv("SECRET_KEY") or secrets.token_hex(32)

    # SQLite database file (created automatically on first run)
    DATABASE_PATH = BASE_DIR / "database" / "health.db"

    # External AI API (Google Gemini)
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip()
    AI_TIMEOUT_SECONDS = 25
