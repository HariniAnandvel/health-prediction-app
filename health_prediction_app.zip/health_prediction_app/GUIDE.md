# HealthPredict – Installation, Testing, Video, GitHub & Submission Guide

## Phase 1 – Create the project folder
You received the finished folder `health_prediction_app`. Unzip it somewhere simple, e.g. `C:\Projects\health_prediction_app`, then open that folder in VS Code (File → Open Folder). Every file is already in its correct place (see the structure in README.md).

## Phase 2 – Installation (Windows PowerShell)
Open PowerShell inside the project folder (VS Code: Terminal → New Terminal).
```powershell
python --version                       # needs Python 3.10 or newer
python -m venv venv                    # create virtual environment
venv\Scripts\Activate.ps1              # activate it (you will see (venv) at the start of the line)
pip install -r requirements.txt        # install Flask, requests, python-dotenv
Copy-Item .env.example .env            # create your private .env file
notepad .env                           # paste your key after GEMINI_API_KEY= , save, close
python app.py                          # run the app
```
Open **http://127.0.0.1:5000** in your browser. Stop the app with `Ctrl + C`.

If PowerShell blocks activation: run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, answer `Y`, then activate again.

**Get the API key (free):** go to https://aistudio.google.com/apikey → sign in with Google → *Create API key* → copy it into `.env` as `GEMINI_API_KEY=...` (no quotes, no spaces). If the model name ever stops working, change `GEMINI_MODEL` in `.env` to another current Gemini Flash model and restart.

## Phase 3 – Testing checklist

### Test data (enter exactly as given; dates use `/` because the app requires dd/mm/yyyy)
| # | Name | DOB | Email | Glucose | Hb | Chol | Expected |
|---|---|---|---|---|---|---|---|
| 1 | Robyn Pears | 28/01/1960 | robyn@gmail.com | 232 | 13.5 | 180 | ✅ Saved |
| 2 | John Hunter | 10/12/1990 | hunter@gmail | 94 | 15 | 200 | ❌ Invalid email (domain has no .com) |
| 3 | Darryl Tim | 12/11/1993 | timd@smh.com.au | 240 | 18.6 | 326 | ✅ Saved |
| 4 | Peter Larry | 31/11/2001 | Larry@hotmail.com | 88 | 11.5 | 165 | ❌ Invalid date (November has 30 days) |
| 5 | Sam Kerr | 09/12/2006 | sam@news.com.au | 198 | 8.9 | 192 | ✅ Saved |
| 6 | Robyn Pears | 28/01/1960 | robyn@gmail.com | 232 | 13.5 | 180 | ❌ Duplicate email (already saved as #1) |
| 7 | Madison XI | 12/09/1998 | madison@hotmail.com | 85 | 7.6 | 163 | ✅ Saved |
| 8 | Kris Wu | 19/10/2030 | Kris.wu.gmail.com | 79 | 16.5 | 197 | ❌ Future DOB **and** email missing "@" |
| 9 | Tenille Singh | 30/11/1991 | Tenille@yahoo.com | 101 | 15 | 310 | ✅ Saved |
| 10 | Prem Kumar | 28/04/1990 | prem@telstra.com | 155 | 12.5 | 265 | ✅ Saved |

**Result: 6 saved, 4 rejected.** Record 6 is rejected because the app blocks duplicate emails. If your evaluator expects it to be saved, delete the two `email_exists` blocks in `app.py` (one in `create_patient`, one in `edit_patient`).

### Create
1. Click **Add Patient**, enter record 1, click **Save Patient**.
   Expected: spinner, then redirect to Patient Records with a green "saved successfully" message and the new row.

### Read
1. Records page shows the table and "Total patients: N". 2. Click **View** → full details and AI remarks. 3. Search `robyn` → only matching rows; search `zzz` → "No matching patients". 4. Click **Clear**.

### Update
1. Click **Edit** on Prem Kumar, change email to `gokul@infocare.com`, **Save Changes**. Expected: green success message, new email in the list. (Blood values unchanged → remarks are kept.)
2. Edit again and change Glucose to `100`. Expected: success, and the View page shows a **new** AI remark.

### Delete
1. Click **Delete** on Sam Kerr → dialog "Delete patient record?" → **Cancel** keeps the record. 2. Delete again → **Yes, delete** → green message, record gone, count reduced. Refresh the page / restart the app: it stays deleted.

### Validation errors
Enter records 2, 4, 8, 6. Expected: red box "The record was NOT saved" with the specific reasons and red fields; nothing appears in the table. Also try: empty name, DOB `1/1/2000` (wrong format), Glucose `abc`, Cholesterol empty.

### AI integration
1. With a valid key: View a patient → remarks paragraph ending with "informational only and is not a medical diagnosis".
2. Failure test: put a wrong key in `.env`, restart, add a patient. Expected: patient saved + yellow warning "AI remarks could not be generated: The AI API key was rejected…", app does not crash. Fix the key, restart, open the patient → **Generate AI remarks**.

### Persistence
Stop the app (`Ctrl + C`), run `python app.py` again → all records are still there (stored in `database\health.db`).

## Phase 4 – Video demonstration (about 6–8 minutes)
Record with Windows Game Bar (`Win + G`) or OBS. Speak slowly; read the script naturally in your own words. Before recording, delete `database\health.db` (with the app stopped) so you start empty.

| Step | On screen | Say |
|---|---|---|
| 1 Overview | Dashboard (empty state) | "This is HealthPredict, a Flask web app that manages patient blood test records and uses an external AI API to generate health remarks. It supports create, read, update and delete." |
| 2 Create | Add Patient → enter record 1 → Save | "I enter the patient details and blood values. When I save, the app validates the data, calls the AI API, and stores everything in SQLite." |
| 3 Invalid records | Enter 2, then 4, then 8, then show 6 later | "Record 2 fails because the email has no .com ending. Record 4 fails because 31 November doesn't exist. Record 8 has a future date of birth and an email without '@'. Nothing invalid is saved." |
| 4 Valid records | Enter 3, 5, 7, 9, 10, then 6 | "These are valid so they are saved. Record 6 is a duplicate of Robyn Pears, so the app blocks it." |
| 5 Read | Patient Records, search `tenille`, click View | "Here are all records with a total count. I can search by name or email and view full details including the AI remarks." |
| 6 Edit | Edit Prem Kumar → email `gokul@infocare.com` → Save | "I update the email. Because the blood values didn't change, the existing AI remark is kept; if they change, a new remark is generated." |
| 7 Delete | Delete Sam Kerr → Cancel → Delete → confirm | "Before deleting, a confirmation dialog appears. After I confirm, the record is permanently removed." |
| 8 Updated list | Records page | "The list now shows the edited email and no deleted record." |
| 9 Backend | Show `app.py` briefly | "Flask routes receive the form, call the validation, AI and database services, then redirect. Each file has one job." |
| 10 Database | Show `database_service.py` | "SQLite stores data in one file, health.db. I use parameterised queries, so user input can never break the SQL." |
| 11 Validation | Show `validation_service.py` | "Each field has a function that returns either clean data or a clear message. The date check uses Python's calendar to catch dates like 31 November, and compares with today's date for future dates." |
| 12 AI API | Show `ai_service.py` and `.env.example` | "I send only the three blood values to the Google Gemini API with a prompt asking for a short, cautious summary. The API key comes from the .env file, which is excluded from GitHub. If the API fails, the app shows a warning and keeps working." |

**Interview answers to memorise:** *Why Flask?* Simple and good for learning. *Why SQLite?* No server needed, data persists in a file. *How is the key protected?* Environment variable in `.env`, ignored by Git. *What if the AI is down?* Record is saved, warning shown, retry button available.

## Phase 5 – GitHub submission
1. Create an account at https://github.com, then click **+ → New repository**. Name: `health-prediction-app`. Choose **Public**. Do **not** tick README/.gitignore (they already exist). Click **Create repository**.
2. Install Git from https://git-scm.com if `git --version` fails.
3. In PowerShell, inside the project folder:
```powershell
git init
git config user.name "Your Name"
git config user.email "you@example.com"
git add .
git status                      # CHECK: .env and venv must NOT be listed
git commit -m "Initial commit: HealthPredict Flask app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/health-prediction-app.git
git push -u origin main
```
(Sign in via the browser window if asked.)
4. **Safety check:** refresh the GitHub page. You must see `.env.example` but **not** `.env`. If `.env` was uploaded, regenerate your API key immediately at Google AI Studio.
5. Your link is the page URL: `https://github.com/YOUR-USERNAME/health-prediction-app`.

## Phase 6 – Final submission checklist
- [ ] Full name, phone number and email address
- [ ] GitHub repository link (open it in a private window to confirm it is public)
- [ ] Video file or link (upload to Google Drive/YouTube as *Unlisted* and set sharing to "Anyone with the link")
- [ ] Repo contains README.md, requirements.txt, `.env.example`, and no `.env` or API key
- [ ] App starts from a fresh clone using the README steps
- [ ] Video shows all 12 steps, including the email change to gokul@infocare.com and one delete

**Email template**
> Subject: Python Skills Evaluation – [Your Full Name]
>
> Hello [Name],
> Please find my submission for the Python skills evaluation.
> Candidate: [Full name], [phone], [email]
> GitHub repository: [link]
> Demonstration video: [link]
> The README explains how to install and run the application. Thank you for your time.
> Regards, [Your Full Name]
