"""Validation rules. Invalid data is rejected with a clear, specific message."""
import calendar
import re
from datetime import date

EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}$")
DATE_PATTERN = re.compile(r"\d{2}/\d{2}/\d{4}")
NUMBER_PATTERN = re.compile(r"\d+(\.\d+)?")

# field name: (label, unit, minimum, maximum)
BLOOD_RULES = {
    "glucose": ("Glucose", "mg/dL", 10, 1000),
    "haemoglobin": ("Haemoglobin", "g/dL", 1, 30),
    "cholesterol": ("Cholesterol", "mg/dL", 50, 1000),
}


def validate_name(value):
    name = value.strip()
    if not name:
        return None, "Full name cannot be empty."
    if len(name) > 100:
        return None, "Full name must be 100 characters or fewer."
    return name, None


def validate_email(value):
    email = value.strip()
    if not email:
        return None, "Email address cannot be empty."
    if "@" not in email:
        return None, f"'{email}' is not a valid email: it is missing the '@' symbol (example: name@example.com)."
    if email.count("@") > 1:
        return None, f"'{email}' is not a valid email: it contains more than one '@' symbol."
    domain = email.split("@")[1]
    if "." not in domain:
        return None, f"'{email}' is not a valid email: the domain is incomplete, it needs an ending such as .com (example: name@gmail.com)."
    if not EMAIL_PATTERN.match(email):
        return None, f"'{email}' is not a valid email format (example: name@example.com)."
    return email, None


def validate_dob(value):
    """Accepts dd/mm/yyyy only. Returns the date as yyyy-mm-dd for the database."""
    text = value.strip()
    if not text:
        return None, "Date of birth cannot be empty. Use dd/mm/yyyy (example: 28/01/1960)."
    if not DATE_PATTERN.fullmatch(text):
        return None, f"'{text}' is not in dd/mm/yyyy format. Use two digits for day and month and slashes (example: 28/01/1960)."

    day, month, year = (int(part) for part in text.split("/"))
    if not 1 <= month <= 12:
        return None, f"'{text}' is not a real date: the month must be between 01 and 12."
    if year < 1900:
        return None, f"'{text}' is not accepted: the year must be 1900 or later."

    last_day = calendar.monthrange(year, month)[1]
    if not 1 <= day <= last_day:
        return None, f"'{text}' is not a real calendar date: {calendar.month_name[month]} {year} only has {last_day} days."

    dob = date(year, month, day)
    if dob > date.today():
        return None, f"Date of birth '{text}' is in the future. It must be today or earlier."
    return dob.isoformat(), None


def validate_blood_value(field, value):
    label, unit, minimum, maximum = BLOOD_RULES[field]
    text = value.strip()
    if not text:
        return None, f"{label} cannot be empty."
    if not NUMBER_PATTERN.fullmatch(text):
        return None, f"{label} must be a number (digits and one decimal point only). '{text}' is not valid."
    number = float(text)
    if not minimum <= number <= maximum:
        return None, f"{label} must be between {minimum} and {maximum} {unit}. You entered {text}."
    return number, None


def validate_patient(form):
    """Check every field. Returns (cleaned_data, errors). Save only if errors is empty."""
    cleaned, errors = {}, {}

    checks = {
        "full_name": validate_name,
        "dob": validate_dob,
        "email": validate_email,
    }
    for field, check in checks.items():
        cleaned[field], message = check(form.get(field, ""))
        if message:
            errors[field] = message

    for field in BLOOD_RULES:
        cleaned[field], message = validate_blood_value(field, form.get(field, ""))
        if message:
            errors[field] = message

    return cleaned, errors
