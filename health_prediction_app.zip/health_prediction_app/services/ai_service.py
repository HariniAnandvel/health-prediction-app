"""Talks to the external AI API (Google Gemini) to generate health remarks."""
import requests

from config import Config

DISCLAIMER = "Note: This result is informational only and is not a medical diagnosis."

HTTP_ERRORS = {
    400: "The AI service rejected the request. Check GEMINI_MODEL in your .env file.",
    401: "The AI API key was rejected. Check GEMINI_API_KEY in your .env file.",
    403: "The AI API key was rejected. Check GEMINI_API_KEY in your .env file.",
    404: "The AI model was not found. Check GEMINI_MODEL in your .env file.",
    429: "The AI service rate limit was reached. Please wait a minute and try again.",
}


class AIServiceError(Exception):
    """Raised when remarks cannot be generated. The message is safe to show to users."""


def generate_remarks(glucose, haemoglobin, cholesterol):
    """Send ONLY the three blood values (no name/email) and return a short summary."""
    if not Config.GEMINI_API_KEY:
        raise AIServiceError("GEMINI_API_KEY is not set. Add it to your .env file and restart the app.")

    prompt = (
        "You are a health information assistant. A person has these blood test results:\n"
        f"- Glucose: {glucose:g} mg/dL (assume fasting)\n"
        f"- Haemoglobin: {haemoglobin:g} g/dL\n"
        f"- Total cholesterol: {cholesterol:g} mg/dL\n\n"
        "In plain text with no markdown or bullet points and at most 90 words, summarise the "
        "possible health risks or conditions these values may point to, then give one simple "
        "lifestyle or follow-up suggestion. Use cautious wording such as 'may' or 'could suggest'. "
        "State clearly that this is informational only and not a medical diagnosis."
    )

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{Config.GEMINI_MODEL}:generateContent"
    headers = {"Content-Type": "application/json", "x-goog-api-key": Config.GEMINI_API_KEY}
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 1024},
    }

    try:
        response = requests.post(url, headers=headers, json=body, timeout=Config.AI_TIMEOUT_SECONDS)
    except requests.exceptions.Timeout:
        raise AIServiceError("The AI service took too long to respond. Please try again.")
    except requests.exceptions.ConnectionError:
        raise AIServiceError("Could not connect to the AI service. Check your internet connection.")
    except requests.exceptions.RequestException:
        raise AIServiceError("Something went wrong while contacting the AI service.")

    if response.status_code != 200:
        message = HTTP_ERRORS.get(response.status_code)
        if message is None:
            message = (
                "The AI service is temporarily unavailable. Please try again later."
                if response.status_code >= 500
                else f"The AI service returned an error (HTTP {response.status_code})."
            )
        raise AIServiceError(message)

    try:
        text = response.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (KeyError, IndexError, TypeError, ValueError):
        raise AIServiceError("The AI service returned an unexpected response. Please try again.")

    if not text:
        raise AIServiceError("The AI service returned an empty response. Please try again.")
    return f"{text}\n\n{DISCLAIMER}"
