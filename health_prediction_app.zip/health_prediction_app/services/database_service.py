"""All SQLite database logic lives here (create, read, update, delete)."""
import sqlite3
from contextlib import contextmanager

from config import Config


@contextmanager
def get_connection():
    """Open a connection, save changes if all went well, always close it."""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create the patients table if it does not exist yet."""
    Config.DATABASE_PATH.parent.mkdir(exist_ok=True)
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS patients (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name    TEXT NOT NULL,
                dob          TEXT NOT NULL,          -- stored as yyyy-mm-dd
                email        TEXT NOT NULL,
                glucose      REAL NOT NULL,
                haemoglobin  REAL NOT NULL,
                cholesterol  REAL NOT NULL,
                remarks      TEXT,                   -- AI generated remarks
                created_at   TEXT NOT NULL DEFAULT (datetime('now')),
                updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
            )
            """
        )


def create_patient(data, remarks):
    """Insert a new patient and return the new id."""
    with get_connection() as conn:
        cursor = conn.execute(
            """INSERT INTO patients
               (full_name, dob, email, glucose, haemoglobin, cholesterol, remarks)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (data["full_name"], data["dob"], data["email"], data["glucose"],
             data["haemoglobin"], data["cholesterol"], remarks),
        )
        return cursor.lastrowid


def get_all_patients(search=""):
    """Return all patients (newest first). Optional search by name or email."""
    query = "SELECT * FROM patients"
    params = ()
    if search:
        query += " WHERE full_name LIKE ? OR email LIKE ?"
        params = (f"%{search}%", f"%{search}%")
    query += " ORDER BY id DESC"
    with get_connection() as conn:
        return [dict(row) for row in conn.execute(query, params).fetchall()]


def get_patient(patient_id):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
        return dict(row) if row else None


def count_patients():
    with get_connection() as conn:
        return conn.execute("SELECT COUNT(*) FROM patients").fetchone()[0]


def update_patient(patient_id, data, remarks):
    with get_connection() as conn:
        conn.execute(
            """UPDATE patients
               SET full_name = ?, dob = ?, email = ?, glucose = ?, haemoglobin = ?,
                   cholesterol = ?, remarks = ?, updated_at = datetime('now')
               WHERE id = ?""",
            (data["full_name"], data["dob"], data["email"], data["glucose"],
             data["haemoglobin"], data["cholesterol"], remarks, patient_id),
        )


def update_remarks(patient_id, remarks):
    with get_connection() as conn:
        conn.execute(
            "UPDATE patients SET remarks = ?, updated_at = datetime('now') WHERE id = ?",
            (remarks, patient_id),
        )


def delete_patient(patient_id):
    """Permanently remove a patient. Returns True if a record was deleted."""
    with get_connection() as conn:
        cursor = conn.execute("DELETE FROM patients WHERE id = ?", (patient_id,))
        return cursor.rowcount > 0


def email_exists(email, exclude_id=None):
    """True if another patient already uses this email (case-insensitive)."""
    query = "SELECT 1 FROM patients WHERE LOWER(email) = LOWER(?)"
    params = [email]
    if exclude_id is not None:
        query += " AND id != ?"
        params.append(exclude_id)
    with get_connection() as conn:
        return conn.execute(query, params).fetchone() is not None
