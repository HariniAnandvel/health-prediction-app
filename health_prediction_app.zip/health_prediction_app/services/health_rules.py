"""Simple reference-range indicators (colour badges). These are NOT the AI remarks."""
from datetime import date


def calculate_age(dob):
    today = date.today()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def _status(label, level):
    return {"label": label, "level": level}  # level: normal / attention / high


def _glucose(value):  # mg/dL, fasting
    if value < 70:
        return _status("Low", "attention")
    if value < 100:
        return _status("Normal", "normal")
    if value < 126:
        return _status("Elevated", "attention")
    return _status("High", "high")


def _haemoglobin(value):  # g/dL, general adult range
    if value < 8:
        return _status("Very low", "high")
    if value < 12:
        return _status("Low", "attention")
    if value <= 17.5:
        return _status("Normal", "normal")
    return _status("High", "attention")


def _cholesterol(value):  # mg/dL, total cholesterol
    if value < 200:
        return _status("Desirable", "normal")
    if value < 240:
        return _status("Borderline", "attention")
    return _status("High", "high")


def analyse(patient):
    """Return a status for each blood value plus an overall risk level."""
    result = {
        "glucose": _glucose(patient["glucose"]),
        "haemoglobin": _haemoglobin(patient["haemoglobin"]),
        "cholesterol": _cholesterol(patient["cholesterol"]),
    }
    levels = [item["level"] for item in result.values()]
    if "high" in levels:
        result["overall"] = _status("High risk", "high")
    elif "attention" in levels:
        result["overall"] = _status("Needs attention", "attention")
    else:
        result["overall"] = _status("Healthy range", "normal")
    return result
