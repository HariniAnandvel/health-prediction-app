# HealthPredict – Health Prediction & Patient Management App

A web application built with **Python Flask** and **SQLite** to record patient blood test results (Glucose, Haemoglobin, Cholesterol), validate the data, and generate an **AI-based health risk remark** using the Google Gemini API. Full CRUD (Create, Read, Update, Delete) is supported.

> The AI remarks are informational only and are **not** a medical diagnosis.

## Features
- Patient registration form with strict backend + light frontend validation
- AI health remark generated from the blood values and saved permanently
- Patient records table with search (name/email), view, edit, delete and total count
- Delete confirmation dialog, success/error notifications, empty states
- Dashboard with total patients, averages and recent records
- Colour-coded indicators based on simple reference ranges
- Responsive Bootstrap 5 UI with desktop sidebar

## Tech Stack
Python 3 · Flask · SQLite · HTML5 · CSS3 · Bootstrap 5 · JavaScript (minimal) · Google Gemini API

## Setup (Windows PowerShell)
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# open .env and paste your own GEMINI_API_KEY
python app.py
```
Open http://127.0.0.1:5000

Get a free Gemini API key at https://aistudio.google.com/apikey

## Project Structure
```
app.py                  Flask routes
config.py               Settings loaded from .env
services/
  database_service.py   All SQLite code
  validation_service.py All validation rules
  ai_service.py         External AI API call
  health_rules.py       Colour indicators and age
templates/              HTML pages (Jinja2)
static/                 CSS and JavaScript
database/               health.db is created here automatically
```

## Validation Rules
| Field | Rule |
|---|---|
| Full name | Required, max 100 characters |
| Date of birth | `dd/mm/yyyy`, real calendar date, not in the future |
| Email | Valid format, unique per patient |
| Glucose / Haemoglobin / Cholesterol | Numbers only (digits + one decimal point) within a sensible range |

Invalid records are never saved. If the AI service is unavailable, the patient is still saved and the user is told remarks could not be generated (they can retry from the patient page).

## Security
- API key and secret key are read from environment variables (`.env`, which is git-ignored)
- All SQL uses parameterised queries; Jinja2 escapes output
- Only the three blood values are sent to the AI API – no name, email or date of birth

## Possible Improvements
CSRF protection (Flask-WTF), user login, pagination, unit tests, deployment.
