// Small, simple JavaScript - only where it improves the user experience.
document.addEventListener("DOMContentLoaded", () => {
  // 1. Success messages disappear automatically after 5 seconds
  document.querySelectorAll('.alert[data-autodismiss="true"]').forEach((alertBox) => {
    setTimeout(() => bootstrap.Alert.getOrCreateInstance(alertBox).close(), 5000);
  });

  // 2. Delete confirmation dialog: fill in the patient name and the delete URL
  const modalElement = document.getElementById("deleteModal");
  const deleteModal = new bootstrap.Modal(modalElement);
  document.querySelectorAll("[data-delete-url]").forEach((button) => {
    button.addEventListener("click", () => {
      document.getElementById("deleteForm").action = button.dataset.deleteUrl;
      document.getElementById("deletePatientName").textContent = button.dataset.patientName;
      deleteModal.show();
    });
  });

  // 3. Show a loading spinner while the AI API is being called
  document.querySelectorAll("form[data-loading]").forEach((form) => {
    form.addEventListener("submit", () => {
      const button = form.querySelector("button[type=submit]");
      button.disabled = true;
      button.innerHTML = `<span class="spinner-border spinner-border-sm me-2"></span>${form.dataset.loading}`;
    });
  });

  // 4. Quick check on blood values (the Python backend still validates everything)
  document.querySelectorAll("input[data-number]").forEach((input) => {
    input.addEventListener("blur", () => {
      const value = input.value.trim();
      const valid = value === "" || /^\d+(\.\d+)?$/.test(value);
      input.classList.toggle("is-invalid", !valid);
      const feedback = input.parentElement.querySelector(".invalid-feedback");
      if (!valid && feedback) feedback.textContent = "Numbers only (digits and one decimal point), e.g. 13.5";
    });
  });
});
