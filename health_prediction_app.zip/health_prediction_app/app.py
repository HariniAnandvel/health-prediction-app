"""HealthPredict - Flask application (routes only; logic lives in /services)."""
from datetime import datetime

from flask import Flask, abort, flash, redirect, render_template, request, url_for

from config import Config
from services import database_service as db
from services import validation_service as validator
from services.ai_service import AIServiceError, generate_remarks
from services.health_rules import analyse, calculate_age

app = Flask(__name__)
app.config.from_object(Config)
db.init_db()

FORM_FIELDS = ("full_name", "dob", "email", "glucose", "haemoglobin", "cholesterol")
BLOOD_FIELDS = ("glucose", "haemoglobin", "cholesterol")


# ---------- helpers ----------
@app.template_filter("num")
def number_text(value):
    """232.0 -> 232, 13.5 -> 13.5"""
    return f"{value:g}"


def to_view(patient):
    """Add display values (dd/mm/yyyy date, age, colour indicators) to a patient."""
    view = dict(patient)
    dob = datetime.strptime(patient["dob"], "%Y-%m-%d").date()
    view["dob_display"] = dob.strftime("%d/%m/%Y")
    view["age"] = calculate_age(dob)
    view["indicators"] = analyse(patient)
    return view


def read_form():
    return {field: request.form.get(field, "") for field in FORM_FIELDS}


def try_generate_remarks(values):
    """Return (remarks, error_message). The app never crashes if the API fails."""
    try:
        remarks = generate_remarks(values["glucose"], values["haemoglobin"], values["cholesterol"])
        return remarks, None
    except AIServiceError as error:
        return None, str(error)
    except Exception:
        return None, "An unexpected error occurred while generating AI remarks."


def average(patients, key):
    return round(sum(p[key] for p in patients) / len(patients), 1) if patients else None


# ---------- pages ----------
@app.route("/")
def dashboard():
    patients = [to_view(p) for p in db.get_all_patients()]
    stats = {
        "total": len(patients),
        "attention": sum(1 for p in patients if p["indicators"]["overall"]["level"] != "normal"),
        "glucose": average(patients, "glucose"),
        "haemoglobin": average(patients, "haemoglobin"),
        "cholesterol": average(patients, "cholesterol"),
    }
    return render_template("dashboard.html", stats=stats, recent=patients[:5])


@app.route("/patients")
def patients_list():
    search = request.args.get("q", "").strip()
    patients = [to_view(p) for p in db.get_all_patients(search)]
    return render_template("patients.html", patients=patients, search=search, total=db.count_patients())


@app.route("/patients/<int:patient_id>")
def patient_detail(patient_id):
    patient = db.get_patient(patient_id)
    if patient is None:
        abort(404)
    return render_template("patient_detail.html", p=to_view(patient))


# ---------- CREATE ----------
@app.route("/patients/new", methods=["GET", "POST"])
def create_patient():
    if request.method == "GET":
        return render_template("patient_form.html", mode="create", form={}, errors={})

    form = read_form()
    cleaned, errors = validator.validate_patient(form)
    if "email" not in errors and db.email_exists(cleaned["email"]):
        errors["email"] = f"A patient with the email '{cleaned['email']}' already exists. Duplicate records are not allowed."
    if errors:  # invalid records are never saved
        return render_template("patient_form.html", mode="create", form=form, errors=errors)

    remarks, ai_error = try_generate_remarks(cleaned)
    db.create_patient(cleaned, remarks)
    flash(f"Patient '{cleaned['full_name']}' was saved successfully.", "success")
    if ai_error:
        flash(f"AI remarks could not be generated: {ai_error} You can retry from the patient's page.", "warning")
    return redirect(url_for("patients_list"))


# ---------- UPDATE ----------
@app.route("/patients/<int:patient_id>/edit", methods=["GET", "POST"])
def edit_patient(patient_id):
    patient = db.get_patient(patient_id)
    if patient is None:
        abort(404)

    if request.method == "GET":
        form = {
            "full_name": patient["full_name"],
            "dob": to_view(patient)["dob_display"],
            "email": patient["email"],
            **{field: number_text(patient[field]) for field in BLOOD_FIELDS},
        }
        return render_template("patient_form.html", mode="edit", form=form, errors={}, patient_id=patient_id)

    form = read_form()
    cleaned, errors = validator.validate_patient(form)
    if "email" not in errors and db.email_exists(cleaned["email"], exclude_id=patient_id):
        errors["email"] = f"Another patient already uses the email '{cleaned['email']}'."
    if errors:
        return render_template("patient_form.html", mode="edit", form=form, errors=errors, patient_id=patient_id)

    values_changed = any(patient[field] != cleaned[field] for field in BLOOD_FIELDS)
    remarks, ai_error = patient["remarks"], None
    if values_changed or not patient["remarks"]:
        remarks, ai_error = try_generate_remarks(cleaned)  # new values -> new AI remark

    db.update_patient(patient_id, cleaned, remarks)
    flash(f"Patient '{cleaned['full_name']}' was updated successfully.", "success")
    if ai_error:
        flash(f"AI remarks could not be generated: {ai_error} You can retry from the patient's page.", "warning")
    return redirect(url_for("patients_list"))


@app.route("/patients/<int:patient_id>/regenerate", methods=["POST"])
def regenerate_remarks(patient_id):
    patient = db.get_patient(patient_id)
    if patient is None:
        abort(404)
    remarks, ai_error = try_generate_remarks(patient)
    if ai_error:
        flash(f"AI remarks could not be generated: {ai_error}", "danger")
    else:
        db.update_remarks(patient_id, remarks)
        flash("AI remarks were generated successfully.", "success")
    return redirect(url_for("patient_detail", patient_id=patient_id))


# ---------- DELETE ----------
@app.route("/patients/<int:patient_id>/delete", methods=["POST"])
def delete_patient(patient_id):
    patient = db.get_patient(patient_id)
    if patient is None:
        abort(404)
    db.delete_patient(patient_id)
    flash(f"Patient '{patient['full_name']}' was deleted permanently.", "success")
    return redirect(url_for("patients_list"))


@app.errorhandler(404)
def not_found(_error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(debug=True)
